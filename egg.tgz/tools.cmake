# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(Zephyrus src/Zephyrus.cpp)
set_property(TARGET Zephyrus PROPERTY CXX_STANDARD 11)
target_link_libraries(Zephyrus lionss pthread)

add_executable(ekf_predict src/ekf_predict.cpp)
set_property(TARGET ekf_predict PROPERTY CXX_STANDARD 11)
target_link_libraries(ekf_predict lionss pthread)

add_executable(DedupeSilver src/DedupeSilver.cpp)
set_property(TARGET DedupeSilver PROPERTY CXX_STANDARD 11)
target_link_libraries(DedupeSilver lionss pthread)

add_executable(golden_approve src/golden_approve.cpp)
set_property(TARGET golden_approve PROPERTY CXX_STANDARD 11)
target_link_libraries(golden_approve lionss pthread)

add_executable(riscv-mret src/riscv-mret.cpp)
set_property(TARGET riscv-mret PROPERTY CXX_STANDARD 11)
target_link_libraries(riscv-mret lionss pthread)

add_executable(prometheus_scrape src/prometheus_scrape.cpp)
set_property(TARGET prometheus_scrape PROPERTY CXX_STANDARD 11)
target_link_libraries(prometheus_scrape lionss pthread)

add_executable(webrtcDtls src/webrtcDtls.cpp)
set_property(TARGET webrtcDtls PROPERTY CXX_STANDARD 11)
target_link_libraries(webrtcDtls lionss pthread)

add_executable(avr_watchdog src/avr_watchdog.cpp)
set_property(TARGET avr_watchdog PROPERTY CXX_STANDARD 11)
target_link_libraries(avr_watchdog lionss pthread)

add_executable(dedupeBlock src/dedupeBlock.cpp)
set_property(TARGET dedupeBlock PROPERTY CXX_STANDARD 11)
target_link_libraries(dedupeBlock lionss pthread)

add_executable(snp-call src/snp-call.cpp)
set_property(TARGET snp-call PROPERTY CXX_STANDARD 11)
target_link_libraries(snp-call lionss pthread)

add_executable(kingfisher-3 src/kingfisher-3.cpp)
set_property(TARGET kingfisher-3 PROPERTY CXX_STANDARD 11)
target_link_libraries(kingfisher-3 lionss pthread)

add_executable(hlsl_reflect src/hlsl_reflect.cpp)
set_property(TARGET hlsl_reflect PROPERTY CXX_STANDARD 11)
target_link_libraries(hlsl_reflect lionss pthread)

add_executable(reactionWheel src/reactionWheel.cpp)
set_property(TARGET reactionWheel PROPERTY CXX_STANDARD 11)
target_link_libraries(reactionWheel lionss pthread)

add_executable(brightwater-7 src/brightwater-7.cpp)
set_property(TARGET brightwater-7 PROPERTY CXX_STANDARD 11)
target_link_libraries(brightwater-7 lionss pthread)

add_executable(ThistleDown src/ThistleDown.cpp)
set_property(TARGET ThistleDown PROPERTY CXX_STANDARD 11)
target_link_libraries(ThistleDown lionss pthread)

add_executable(dx12_barrier src/dx12_barrier.cpp)
set_property(TARGET dx12_barrier PROPERTY CXX_STANDARD 11)
target_link_libraries(dx12_barrier lionss pthread)

add_executable(Vp9Svc src/Vp9Svc.cpp)
set_property(TARGET Vp9Svc PROPERTY CXX_STANDARD 11)
target_link_libraries(Vp9Svc lionss pthread)

add_executable(canopy src/canopy.cpp)
set_property(TARGET canopy PROPERTY CXX_STANDARD 11)
target_link_libraries(canopy lionss pthread)

add_executable(loopUnroll8 src/loopUnroll8.cpp)
set_property(TARGET loopUnroll8 PROPERTY CXX_STANDARD 11)
target_link_libraries(loopUnroll8 lionss pthread)

add_executable(tiering-osr src/tiering-osr.cpp)
set_property(TARGET tiering-osr PROPERTY CXX_STANDARD 11)
target_link_libraries(tiering-osr lionss pthread)

add_executable(glint src/glint.cpp)
set_property(TARGET glint PROPERTY CXX_STANDARD 11)
target_link_libraries(glint lionss pthread)

add_executable(timeTravelDebug src/timeTravelDebug.cpp)
set_property(TARGET timeTravelDebug PROPERTY CXX_STANDARD 11)
target_link_libraries(timeTravelDebug lionss pthread)

add_executable(fft-window-hann src/fft-window-hann.cpp)
set_property(TARGET fft-window-hann PROPERTY CXX_STANDARD 11)
target_link_libraries(fft-window-hann lionss pthread)

add_executable(Tanager src/Tanager.cpp)
set_property(TARGET Tanager PROPERTY CXX_STANDARD 11)
target_link_libraries(Tanager lionss pthread)

add_executable(feldspar src/feldspar.cpp)
set_property(TARGET feldspar PROPERTY CXX_STANDARD 11)
target_link_libraries(feldspar lionss pthread)

add_executable(msp430lpm src/msp430lpm.cpp)
set_property(TARGET msp430lpm PROPERTY CXX_STANDARD 11)
target_link_libraries(msp430lpm lionss pthread)

add_executable(FioRandwrite src/FioRandwrite.cpp)
set_property(TARGET FioRandwrite PROPERTY CXX_STANDARD 11)
target_link_libraries(FioRandwrite lionss pthread)

add_executable(btree-vacuum src/btree-vacuum.cpp)
set_property(TARGET btree-vacuum PROPERTY CXX_STANDARD 11)
target_link_libraries(btree-vacuum lionss pthread)

add_executable(ParquetRollup src/ParquetRollup.cpp)
set_property(TARGET ParquetRollup PROPERTY CXX_STANDARD 11)
target_link_libraries(ParquetRollup lionss pthread)

add_executable(dapple src/dapple.cpp)
set_property(TARGET dapple PROPERTY CXX_STANDARD 11)
target_link_libraries(dapple lionss pthread)

