// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Approve golden output\n", stdout);
  return lionss_run_workload("golden_approve");
}
