// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Insert resource barriers\n", stdout);
  return lionss_run_workload("dx12_barrier");
}
