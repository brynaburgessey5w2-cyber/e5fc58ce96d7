// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Drift thistledown seeds"); }
int main(){
  announce();
  return lionss_run_workload("ThistleDown");
}
