// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Random write test"); }
int main(){
  announce();
  return lionss_run_workload("FioRandwrite");
}
